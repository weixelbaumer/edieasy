<?php

// include TPLN
include('/TPLN/TPLN.php');

$TPLN = new TPLN;
$TPLN->Open('exit.tpln');
$TPLN->Parse('by_bloc.by_text','Thanks for you visite, see you soon !');
$TPLN->Write();

session_destroy();
?>
