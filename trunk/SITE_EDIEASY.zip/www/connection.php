<?php
session_name('Private');
session_start();
$private_id = session_id();

// include TPLN
include('/TPLN/TPLN.php');

// include conncion.inc.php for function...
include('/include/connection.inc.php');

$TPLN = new TPLN();

$TPLN->formSetLang('en');
$TPLN->formSetName('login'); // specify a form name
 
// change error display mode
if(!isset($_GET['display_mode']) || ($_GET['display_mode'] != 'T' && $_GET['display_mode'] != 'I'))
    $TPLN->formSetDisplayMode('I');
else
    $TPLN->formSetDisplayMode($_GET['display_mode']);
 
$TPLN->Open('connection.tpln');

// rules
$TPLN->NotEmpty('User');
$TPLN->AlphaNumeric('User', '_'); // only characters and _
$TPLN->NotEmpty('Password');
// $TPLN->NotEmpty('Email');
// $TPLN->Email('Email');

if($_POST)
    echo "Number of error in the form: ".$TPLN->formGetTotalError();

if (($TPLN->formGetTotalError() === 0) && (!empty($_POST['User'])))
{
	$User = $_POST['User'];
	$Password = $_POST['Password'];
	$TPLN->dbConnect();
	$Query = "SELECT Id, ConnectionNb FROM profil WHERE Login='".$User."' AND Password='".$Password."'";

	$TPLN->doQuery($Query);
 	$count = $TPLN->dbNumRows(); // nuber of records
	$res = $TPLN->getData(); // all data

	
	// FIND -> Connection OK!!!
	if ($count === 1) {
		
	   $profil_id = $res[0]['Id'];
	   $_SESSION['profil_id'] = $profil_id;
	   session_write_close(); 

	   $NB = $res[0]['ConnectionNb'];
	   $NB++;
	   
	   $Query = "UPDATE profil SET ConnectionNb=".$NB.", LastDate='".date('Y-m-d H:i:s')."' WHERE Id=".$profil_id;
	   $TPLN->doQuery($Query);

	   $TPLN->DbClose();
	   $TPLN->redirect("./actions.php");
	   
	} else {
		
	   $TPLN->DbClose();
   	   $TPLN->addError('User','Couple User/Password not find in database!!!'); 
   	   $TPLN->formIsValid();
	}

} else {
	$TPLN->formIsValid();
}

$TPLN->Write();

?> 
