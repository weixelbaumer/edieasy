<?php

// include TPLN
include('/TPLN/TPLN.php');
include('./include/asklogin.inc.php');
	
$TPLN = new TPLN();

$TPLN->formSetLang('en');
$TPLN->formSetName('formLogin'); // specify a form name
$Login = "N/A";
$Password = "N/A";

// change error display mode
if(!isset($_GET['display_mode']) || ($_GET['display_mode'] != 'T' && $_GET['display_mode'] != 'I'))
    $TPLN->formSetDisplayMode('I');
else
    $TPLN->formSetDisplayMode($_GET['display_mode']);
 
$TPLN->Open('asklogin.tpln');

// rules
$TPLN->NotEmpty('Firstname');
$TPLN->AlphaNumeric('Firstname', '_'); // only characters and _
$TPLN->NotEmpty('Familyname');
$TPLN->NotEmpty('Email');
$TPLN->Email('Email');

if($_POST)
    echo "Number of error in the form: ".$TPLN->formGetTotalError();

if (($TPLN->formGetTotalError() === 0) && (!empty($_POST['Firstname'])))
{
	$Firstname  = $_POST['Firstname'];
	$Familyname = $_POST['Familyname'];
	$Email      = $_POST['Email'];
	$Login      = $Firstname[0].$Familyname;
	$Password   = generatePassword(9,1);
	$TPLN->dbConnect();
	$Query = "SELECT Firstname, Familyname, Login, Password FROM profil WHERE FirstName='".$Firstname."' AND FamilyName='".$Familyname."' AND Login='".$Login."'"; 

	$TPLN->doQuery($Query);
	
 	$count = $TPLN->dbNumRows(); // number of records
 	
 	if ($count === 1) {
 
 	   $TPLN->addError('Firstname','Couple Firstname/Familyname exist on database!!!');
	   $TPLN->formIsValid();
	   
   	} else {
   		
   	   $Query = "INSERT INTO profil (Id, FirstName, FamilyName, Login, Password, Email, Categorie, CreationDate) VALUES(NULL,'".$Firstname."', '".$Familyname."', '".$Login."', '".$Password."', '".$Email."', 'DEMO', NULL)"; 
   	   $TPLN->doQuery($Query);
	   $TPLN->DbClose();
	   $TPLN->Parse('Login',$Login);
	   $TPLN->Parse('Password',$Password);
	   $TPLN->formIsValid();
	}

 	$TPLN->DbClose();
 		
} else {
   $TPLN->formIsValid();
}

$TPLN->Write();

?> 
