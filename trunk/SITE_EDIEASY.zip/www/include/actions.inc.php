<?php
$menu[] = array('label'=>'Home','link'=>'?id=1');
$menu[] = array('label'=>'My profil','link'=>'?id=2');
$menu[] = array('label'=>'History','link'=>'?id=3');
$menu[] = array('label'=>'Scripts','link'=>'?id=4');
$menu[] = array('label'=>'Translation','link'=>'?id=5');
$menu[] = array('label'=>'Statistique','link'=>'?id=6');

$Main = "main";

if(isset($_GET['id']))    
    {
        $id = $_GET['id'];

        // Alimentation de la page principale selon le code id
    switch ($id) {
    /// Home	    
    case '1' : {
    		    $Main = "home";
    		    break;
    }
    // My profil (user, name, email, change password, change email..)
    case '2' : {
    		    $Main = "myprofil";
    		    break;
    }
    // List History translation (date  time, session_number, name_script, statut, link_rapport, link_datafile, link_script) 
    case '3' : {
    		    $Main = "history";
    		    break;
    }
    // List scripts, link_seeSource, date_input, version_scripts, link_documentation
    case '4' : {
    		    $Main = "scripts";
    		    break;
    }
    // List scripts
    case '41' : {
    		    $Main = "scripts_list";
    		    break;
    }
    // Manage scripts access
    case '42' : {
    		    $Main = "scripts_access";
    		    break;
    }
    // select scripts, upload data_file, submit control
    case '5' : {
    		    $Main = "translation";
    		    break;
    }
    // statistique ....
    case '6' : {
    		    $Main = "statistique";
    		    break;
    }
    	    
    }
} 

	
$Templates = array('ALL'=>'multiple_templates.tpln',
                            'TOP'=>'top.html',
                            'MAIN'=>'main.tpln',
                            'MENU'=>'menu.html',
                            'BOTTOM'=>'bottom.html');

$Templates["MAIN"] = $Main.".tpln";
?>
