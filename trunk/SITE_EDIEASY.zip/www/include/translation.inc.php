<?php
$TPLN->DbConnect();
$TPLN->formSetLang('en');


// initialiaze record
$profil_id = $_SESSION['profil_id'];
	
	$Query = "SELECT Id_Format AS value, CodeValue AS text FROM script_format";	
	$TPLN->DoQuery($Query);
	$Format_options = '';
	while($row = $TPLN->DBFetch()) {
		$Format_options .= "<option value=\"{$row['value']}\"";
		if(isset($_GET['Format']) && ($_GET['Format'] === $row['value']))
			$Format_options .= "selected";
		    
		$Format_options .=">{$row['text']}</option>\n";
	}
 	$TPLN->Parse('Format_options',$Format_options);
 	
// value selected ?
if(isset($_GET['Format']) && ($_GET['Format'] <> ""))
{    
	$Query = "SELECT Name AS text, Code AS value FROM script, script_access WHERE Id_profil=".$profil_id." AND Id_script=Id AND Format=".$TPLN->checkQuotes($_GET['Format']);	
	$TPLN->DoQuery($Query);
	$Script_options = '';
	while($row = $TPLN->DBFetch())
		$Script_options .= "<option value=\"{$row['value']}\">{$row['text']}</option>\n";
 	$TPLN->Parse('Script_options',$Script_options);
}

$TPLN->notEmpty('Format', 'Format must be filled');
$TPLN->notEmpty('Script', 'Script must be filled');
$TPLN->notEmpty('datafile', 'datafile must be filled');

// Control datafile
$TPLN->fileControl('datafile', 1, '50Ko', '', 'edi');
 
// here one test if the form is valid or not, the parameter allows us to keep the data seized by the user
if($TPLN->formIsValid()) 
{ 
    // treatment
    // bloc form_validate is displayed automatically
    $Transaction_number = 1;
    $TPLN->Parse('Transaction_number',$Transaction_number);
    
    // Upload file
    $target_path = "uploads/";
    
    $FileSha1 = sha1_file($_FILES['datafile']['tmp_name']);
    $target_path = $target_path . $FileSha1; 

    if(move_uploaded_file($_FILES['datafile']['tmp_name'], $target_path)) {
    	    $Query = "INSERT INTO profil_file (`Id_file`, `Profile`, `Sha1`, `FileName`, `DateUpload`) VALUES (NULL, '".$profil_id."', '".$FileSha1."', '".$_FILES['datafile']['name']."', CURRENT_TIMESTAMP);";
    	    $T = $TPLN->DoQuery($Query);
    	    
    	    $msg = "The file ".  basename( $_FILES['datafile']['name'])." has been uploaded";
    	    $TPLN->Parse('msg',$msg);
    } else{
    	    echo "There was an error uploading the file, please try again!";
    }

} 
$TPLN->DbClose();

?>
