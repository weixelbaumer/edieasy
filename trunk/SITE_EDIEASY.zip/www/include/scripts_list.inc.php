<?php
$TPLN->SetNavColor('#ffffff','#ffffc0'); // change colors
$TPLN->DbConnect();

if (isset($_GET['Delete']) && ($_GET['Delete'] <> "")) {
	// Find the Source Name on the database
	$Query = "SELECT SourcePHP FROM script WHERE Id = ".$TPLN->checkQuotes($_GET['Delete']);
	$TPLN->DoQuery($Query);
	$row= $TPLN->DBFetch();
	
	// we verify the file PHP exist.. 	
	$chemin = "./scripts/";
	$Fichier = $chemin . $row['SourcePHP'];
	if (is_file($Fichier) && file_exists($Fichier)) {
		// Delete..File
		unlink($Fichier);	
	}
	// Delete DATABASE...
	$Query = "DELETE FROM script WHERE Id=".$TPLN->checkQuotes($_GET['Delete']);	
	$TPLN->DoQuery($Query);
}

$TPLN->urlAddVar("id=41");
$TPLN->ShowRecordsOrderBy(array('Code', 'Name', 'CodeValue','DateUpload')); // filter
$TPLN->ShowRecords('SELECT Id, Code, Name, Version, SourcePHP, CodeValue, DateUpload FROM script, script_format WHERE Format = Id_Format', 10); // only 10 results by page
$TPLN->DbClose();

?> 

