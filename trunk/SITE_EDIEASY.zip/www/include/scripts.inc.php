<?php
$TPLN->DbConnect();
$TPLN->formSetLang('en');


// initialiaze record
$profil_id = $_SESSION['profil_id'];
	
$Query = "SELECT Id_Format AS value, CodeValue AS text FROM script_format";	
$TPLN->DoQuery($Query);
$Format_options = '';
while($row = $TPLN->DBFetch()) {
	$Format_options .= "<option value=\"{$row['value']}\"";
	if(isset($_GET['Format']) && ($_GET['Format'] === $row['value']))
		$Format_options .= "selected";
	    
	$Format_options .=">{$row['text']}</option>\n";
}
$TPLN->Parse('Format_options',$Format_options);

$TPLN->notEmpty('Format', 'Format must be filled');
$TPLN->notEmpty('scriptfile', 'script file must be filled');
$TPLN->notEmpty('scriptcode', 'script code must be filled');
$TPLN->notEmpty('scriptdesc', 'scrip descriprion must be filled');
$TPLN->onlyDigit('scriptversion', 1);

// Control scriptfile
$TPLN->fileControl('scriptfile', 1, '5Ko', '', 'php');
 
// here one test if the form is valid or not, the parameter allows us to keep the data seized by the user
if($TPLN->formIsValid()) 
{     
    // Upload file
    $target_path = "scripts/";
    $Format = $_POST['Format'];
    $Name   = $_POST['scriptdesc'];
    $Code   = $_POST['scriptcode'];
    $Version = $_POST['scriptversion'];
    
    $target_path = $target_path . $_FILES['scriptfile']['name']; 

    if(move_uploaded_file($_FILES['scriptfile']['tmp_name'], $target_path)) {
    	    $Query = "INSERT INTO script (`Code`, `Name`, `Version`, `SourcePHP`, `Format`) VALUES ('".$Code."', '".$Name."', '".$Version."', '".$_FILES['scriptfile']['name']."', '".$Format."');";
    	    $T = $TPLN->DoQuery($Query);
    	    if ($T === TRUE) 
    	    	    $msg = "The file '".  basename( $_FILES['scriptfile']['name'])."' has been uploaded";
    	    else
    	    	    $msg = "ERREUR INSERT ON DATABASE...";
    	    $TPLN->Parse('msg',$msg);
    } else{
    	    echo "There was an error uploading the file, please try again!";
    }

} 
$TPLN->DbClose();

?>
