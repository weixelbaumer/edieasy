<?php

/// redirection into actions page
function CallRedirection() {
    echo "<SCRIPT LANGUAGE=\"JavaScript\"/>";
    echo "function redirect() {";
    echo "window.location='./actions.php'";
    echo "}";
    echo "setTimeout(\"redirect()\",500);";
    echo "</SCRIPT>";
}

?>
