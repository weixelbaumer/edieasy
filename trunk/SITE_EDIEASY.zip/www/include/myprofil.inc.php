<?php

$TPLN->dbConnect();

$Query = "SELECT FirstName, FamilyName, Login, Password, Email, Categorie, CreationDate, ConnectionNb, LastDate FROM profil WHERE Id='".$profil_id."'";
$TPLN->doQuery($Query);

$count = $TPLN->dbNumRows(); // nuber of records
$res = $TPLN->getData(); // all data

$Firstname = $res[0]['FirstName'];
$Familyname =$res[0]['FamilyName'];
$Login = $res[0]['Login'];
$Email = $res[0]['Email'];
$Categorie = $res[0]['Categorie'];
$Creationdate = $res[0]['CreationDate'];
$Count = $res[0]['ConnectionNb'];
$Lastdate = $res[0]['LastDate'];

$TPLN->Parse('Firstname',$Firstname);
$TPLN->Parse('Familyname',$Familyname);
$TPLN->Parse('Login',$Login);
$TPLN->Parse('Email',$Email);
$TPLN->Parse('Categorie',$Categorie);
$TPLN->Parse('Datecreation',$Creationdate);
$TPLN->Parse('Count',$Count);
$TPLN->Parse('Lastdate',$Lastdate);

/***
$TPLN->dump('DB count', $count); 
$TPLN->dump('DB result', $res);
***/

$TPLN->DbClose();

?>
