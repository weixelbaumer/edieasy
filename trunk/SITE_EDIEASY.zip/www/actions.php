<?php
session_name('Private');
session_start();
$private_id = session_id();
$profil_id = $_SESSION['profil_id'];
session_write_close(); 
    
// include TPLN
include('/TPLN/TPLN.php');

// Include pour ce script
require_once('/include/actions.inc.php');

$TPLN = new TPLN;
$TPLN->DefineTemplate($Templates);

// change to TOP template
$TPLN->ChangeTemplate('TOP');
$TPLN->Parse('text','WELCOME TO EDIEASY, EDIFACT TRANSALOR SOLUTION ...');
$top_content = $TPLN->Output();

// change menu
$TPLN->ChangeTemplate('MENU');
$TPLN->LoadArrayInBloc('menu',$menu);
$menu_content = $TPLN->Output();


// main    
$TPLN->ChangeTemplate('MAIN');

if(empty($id))
  {
   $TPLN->ParseBloc('ok','Hello, <br>Welcome on the first free EDIFACT solution.<BR><BR>Webmaster.');
  } 

include('/include/'.$Main.'.inc.php');

$main_content = $TPLN->Output();

// Bottom
$TPLN->ChangeTemplate('BOTTOM');
$bottom_content = $TPLN->Output();

// ALL parse
$TPLN->ChangeTemplate('ALL');

// color
$TPLN->Parse('top_color','#CCCCCC');
$TPLN->Parse('main_color','#FFFFFF');
$TPLN->Parse('menu_color','#E5E5E5');
$TPLN->Parse('bottom_color','#FFFFC0');


$TPLN->FastParse('top_content');
$TPLN->FastParse('menu_content');
$TPLN->FastParse('main_content');
$TPLN->FastParse('bottom_content'); // Include bottom

$TPLN->Write();

?> 
