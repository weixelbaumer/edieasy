<?php
require_once("initialize.php");

$time_start = microtime_float();

$E = new EDIFACT(EDIFACT_RECEIVED);

$E->DisplayClassEdifactInformation();

$E->LoadFile("EDIFACT.txt");

$OK = $E->FindUNH(1);
echo "FIND UNH(1):".$OK."<BR>";
$MessageType = $E->GetMessageType();
echo "Message Type:".$MessageType."<BR>";
$MessageVersion =$E->GetMessageVersion();
echo "Message Version:".$MessageVersion."<BR>";
$MessageRelease = $E->GetMessageRelease();
echo "Message Release:".$MessageRelease."<BR>";
$MessageAgency = $E->GetMessageAgency();
echo "Message Agency:".$MessageAgency."<BR>";
$MessageAssociation = $E->GetMessageAssociation();
echo "Message Association:".$MessageAssociation."<BR>";

$E->LoadMessage($MessageType,$MessageVersion,$MessageRelease);
// echo "TABLE MESSAGE INFO<BR>";
// print_r($E->TABLE_MESSAGE);

echo "**** VALIDATION MESSAGE *** <BR>";
// $E->ValidMessage();
echo "**** FIN VALIDATION MESSAGE *** <BR>";

//echo "<BR>TABLE SEGMENT :<BR>";
//print_r($E->TABLE_SEGMENT);
//echo "<BR>TABLE COMPOSITE ELEMENT :<BR>";
//print_r($E->TABLE_COMPOSITE_ELEMENT);
//echo "<BR>TABLE ELEMENT :<BR>";
// print_r($E->TABLE_ELEMENT);

echo "<BR>";
echo "TABLE INTERCHANGE INFO<BR>";
print_r($E->TABLE_INTERCHANGE);
echo "<BR><BR>";
echo "TABLE SEGMENT UNx:<BR>";
print_r($E->TABLE_SEGMENT["UNB"]);
echo "<BR>";
print_r($E->TABLE_SEGMENT["UNH"]);
echo "<BR>";
print_r($E->TABLE_SEGMENT["UNT"]);
echo "<BR>";
print_r($E->TABLE_SEGMENT["UNZ"]);
echo "<BR>";
echo "<BR>";

// echo "TABLE MESSAGE INFO<BR>";
// print_r($E->TABLE_MESSAGE);
// print_r($E->TABLE_INDEXATION);

// $E->DisplayIndexationMessage();

while ($E->ReadDirectMessage()) {
	echo "Segment Number:".$E->GetCurrentNumberSegment()." => ".$E->GetCurrentSegmentName()." => ".$E->GetCurrentSegmentOccurence()." GROUP:".$E->GetCurrentGroupName()." => ".$E->GetCurrentGroupOccurence()."<BR>";;
	
	// Recherche NAD+IV dans le groupe "2"
	if (strcmp($E->GetCurrentGroupName(),"2") === 0) {
			if (strcmp($E->GetCurrentSegmentName(),"NAD") === 0) {
				if (strcmp($E->GetCurrentDataSegment("10.3035"),"IV") === 0) {
					$NAD_IV = $E->GetCurrentDataSegment("20.C082.10.3039");
					echo "IDENTIFIANT FACTURE A (NAD+IV):".$NAD_IV."<BR>";
					$E->PutBUFFER("FACTURE",1,1,"INVOICE");
					$E->PutBUFFER("FACTURE",1,10,$NAD_IV);
					$E->PutBUFFER("FACTURE",2,12,str_pad($NAD_IV,35,"#"));
					$E->PutBUFFER("FACTURE",2,1,"INV_LINE");
					$E->PutBUFFER("FACTURE",2,100,"POS100");
				} else {
					echo "ERREUR...NAD NON TRAITE ICI:".$E->GetCurrentDataSegment("10.3035")."<BR>";
					$E->ValidCurrentSegment();
					$E->DisplayCurrentSegment();
				}
			}
	}
	
}

echo "END Segment Number:".$E->GetCurrentNumberSegment()." => ".$E->GetCurrentSegmentName()." => ".$E->GetCurrentSegmentOccurence()." GROUP:".$E->GetCurrentGroupName()." => ".$E->GetCurrentGroupOccurence()."<BR>";;

$E->PrintOutputFile("FACTURE");


$time_end = microtime_float();
$time = $time_end - $time_start;
echo "TEMP DE REACTION $time secondes\n";

// include TPLN
include('/TPLN/TPLN.php');

$TPLN = new TPLN;

$langs = explode (',',$_SERVER['HTTP_ACCEPT_LANGUAGE']);

if(count($langs) >= 1)
    $_lang = $langs[0];

$TPLN->Open("testif.tpln");
$TPLN->Write();


?>